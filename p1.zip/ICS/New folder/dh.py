sharedprime = int(input("Enter shared prime(n): "))
sharedbase = int(input("Enter shared base(b): "))
ramsecret = int(input("Enter ram secret(x): "))
shamesecret = int(input("Enter sham secret(y): "))

print ("\n\nShared Prime Is :",sharedprime)
print ("Shared Base Is :",sharedbase)

A = (sharedbase**ramsecret) % sharedprime
print ("\n Ram send ",A," Over Internet")

B = (sharedbase**shamesecret) % sharedprime
print ("\n Sham send ",B," Over Internet")

print ("Private Keys Are :")

AA = (B**ramsecret) % sharedprime

BB = (A**shamesecret) % sharedprime

print ("Ram Shared Secret : ",AA)
print ("Sham Shared Secret :",BB)